
export interface ChartDataPoint {
  year: number;
  savings: number;
}
